<!DOCTYPE html>
<html lang="el">
<head>
    <meta charset="UTF-8">
    <title>Μενού αρχικής σελίδας</title>
</head>
<body>

    <h1>Μενού αρχικής σελίδας</h1>

    <ul>
        <li><a href="#">Νέο εισερχόμενο</a></li>
        <li><a href="#">Νέο εξερχόμενο</a></li>
        <li><a href="#">Φάκελος εισερχομένων</a></li>
        <li><a href="#">Φάκελος εξερχομένων</a></li>
    </ul>

</body>
</html>
