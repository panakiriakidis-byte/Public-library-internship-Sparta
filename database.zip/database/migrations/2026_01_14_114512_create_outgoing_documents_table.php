<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('outgoing_documents', function (Blueprint $table) {
        $table->id();

        $table->unsignedInteger('protocol_number')->nullable(); // ΜΟΝΟ για ανεξάρτητα
        $table->foreignId('incoming_document_id')
            ->nullable()
            ->constrained()
            ->nullOnDelete();

        $table->string('destination_authority');
        $table->text('summary')->nullable();
        $table->date('document_date');
        $table->string('related_numbers')->nullable();
        $table->string('file_folder')->nullable();
        $table->text('comments')->nullable();

        $table->timestamps();
    });


    }

    public function down(): void
    {
        Schema::dropIfExists('outgoing_documents');
    }
};
