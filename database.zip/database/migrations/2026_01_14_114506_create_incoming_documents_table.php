<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('incoming_documents', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('protocol_number')->unique(); // Α/Α
            $table->date('protocol_date');
            $table->string('incoming_number')->nullable();
            $table->string('issue_place')->nullable();
            $table->string('issue_authority')->nullable();
            $table->date('document_date')->nullable();
            $table->text('summary')->nullable();
            $table->string('folder')->nullable();
            $table->timestamps();
        });

    }

    public function down(): void
    {
        Schema::dropIfExists('incoming_documents');
    }
};
