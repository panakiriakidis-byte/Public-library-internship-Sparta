<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
{
    Schema::table('incoming_documents', function (Blueprint $table) {
        $table->unsignedInteger('protocol_number')->nullable()->after('id');
        $table->string('incoming_protocol')->nullable()->after('protocol_number');
        $table->date('incoming_date')->nullable()->after('incoming_protocol');
        $table->string('sender')->nullable()->after('incoming_date');
        $table->string('subject')->nullable()->after('sender');
        $table->date('document_date')->nullable()->after('subject');
        $table->text('comments')->nullable()->after('summary');
    });
}

    /**
     * Reverse the migrations.
     */
    public function down()
{
    Schema::table('incoming_documents', function (Blueprint $table) {
        $table->dropColumn([
            'protocol_number',
            'incoming_protocol',
            'incoming_date',
            'sender',
            'subject',
            'document_date',
            'comments',
        ]);
    });
}
};
