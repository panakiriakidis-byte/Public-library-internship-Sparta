<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IncomingDocument extends Model
{
    protected $table = 'incoming_documents';

    protected $fillable = [
        'protocol_number',
        'incoming_protocol',
        'incoming_date',
        'sender',
        'subject',
        'document_date',
        'summary',
        'comments',
    ];
}
