<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Protocol extends Model
{
    protected $fillable = [
        'protocol_number'
        'protocol_year'
        'received_date'
        'document_number'
        'issued_place'
        'issued_by'
        'document_year'
        'summary'
        'addressed_to'
        'file_path'
        'notes'
        'user_id'
        ];
        
        #'incoming_date',
        #'incoming_sender',
        #'incoming_subject',
        #'incoming_description',
        #'incoming_file',
        #'outgoing_receiver',
        #'outgoing_description',
        #'outgoing_date'
        

}
