<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OutgoingDocument extends Model
{
    protected $fillable = [
        'protocol_number',
        'incoming_document_id',
        'destination_authority',
        'summary',
        'document_date',
        'related_numbers',
        'file_folder',
        'comments',
    ];

    public function incoming()
    {
        return $this->belongsTo(\App\Models\IncomingDocument::class);
    }
}
