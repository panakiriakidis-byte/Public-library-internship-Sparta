<?php

namespace App\Http\Controllers;

use App\Models\IncomingDocument;
use App\Models\OutgoingDocument;

class CommonDocumentController extends Controller
{
    public function index()
    {
        // ΚΟΙΝΑ ΕΙΣΕΡΧΟΜΕΝΑ
        $common_incoming = IncomingDocument::whereIn(
            'received_date',
            OutgoingDocument::pluck('outgoing_date')
        )->get();

        // ΚΟΙΝΑ ΕΞΕΡΧΟΜΕΝΑ
        $common_outgoing = OutgoingDocument::whereIn(
            'outgoing_date',
            IncomingDocument::pluck('received_date')
        )->get();

        return view('documents.common', compact(
            'common_incoming',
            'common_outgoing'
        ));
    }
}
