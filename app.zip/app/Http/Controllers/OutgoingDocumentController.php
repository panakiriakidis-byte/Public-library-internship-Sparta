<?php

namespace App\Http\Controllers;

use App\Models\OutgoingDocument;
use Illuminate\Http\Request;

class OutgoingDocumentController extends Controller
{
    public function index()
    {
        $documents = OutgoingDocument::with('incoming')->paginate(10);
        return view('outgoing.index', compact('documents'));
    }

    public function store(Request $request)
    {
        // 100% ίδια πεδία με τη φόρμα σου
        $validated = $request->validate([
            'destination_authority' => 'required|string',
            'summary'               => 'nullable|string',
            'document_date'         => 'required|date',
            'related_numbers'       => 'nullable|string',
            'file_folder'           => 'required|string',
            'comments'              => 'nullable|string',
        ]);

        // Αφού δεν έχεις επιλογή "απάντηση σε εισερχόμενο" στο form,
        // το εξερχόμενο θεωρείται ανεξάρτητο και παίρνει δικό του Α/Α
        $last = OutgoingDocument::whereNull('incoming_document_id')
            ->max('protocol_number');

        $validated['protocol_number'] = $last ? $last + 1 : 1;
        $validated['incoming_document_id'] = null;

        OutgoingDocument::create($validated);

        return redirect()->back()->with('success', 'Το εξερχόμενο καταχωρήθηκε επιτυχώς.');
    }

    public function edit($id)
    {
        $document = OutgoingDocument::findOrFail($id);
        return view('outgoing.edit', compact('document'));
    }

    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'destination_authority' => 'required|string',
            'summary'               => 'nullable|string',
            'document_date'         => 'required|date',
            'related_numbers'       => 'nullable|string',
            'file_folder'           => 'nullable|string',
            'comments'              => 'nullable|string',
        ]);

        OutgoingDocument::findOrFail($id)->update($validated);

        return redirect()
            ->route('outgoing.index')
            ->with('success', 'Το εξερχόμενο ενημερώθηκε.');
    }

    public function destroy($id)
    {
        OutgoingDocument::findOrFail($id)->delete();
        return redirect()->back()->with('success', 'Το εξερχόμενο διαγράφηκε.');
    }
}
